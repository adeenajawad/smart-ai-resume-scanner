from motor.motor_asyncio import AsyncIOMotorClient
from app.config import settings

client = AsyncIOMotorClient(settings.MONGO_URI)

database = client[settings.DATABASE_NAME]

resume_collection = database.get_collection("resumes")
interview_collection = database.get_collection("interviews")
