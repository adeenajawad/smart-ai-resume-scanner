import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RAW_RESUME_DIR = os.path.join(BASE_DIR, "data", "raw_resumes")
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")

os.makedirs(RAW_RESUME_DIR, exist_ok=True)
os.makedirs(PROCESSED_DIR, exist_ok=True)
