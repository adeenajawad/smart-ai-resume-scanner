from fastapi import APIRouter

router = APIRouter()

@router.get("/questions")
def generate_questions(role: str = "ML Engineer"):
    return {
        "role": role,
        "questions": [
            "Explain overfitting in machine learning.",
            "What is the difference between CNN and ANN?",
            "Explain gradient descent."
        ]
    }
