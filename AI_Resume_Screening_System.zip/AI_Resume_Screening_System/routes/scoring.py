from fastapi import APIRouter

router = APIRouter()

@router.post("/score")
def score_resume():
    return {
        "score": 82,
        "status": "Good Match"
    }
